from pymol import cmd,stored
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000633_ProtDefineStructROIs/8tdu_000633_out.pdb
stored.list=[]
cmd.iterate("(resn STP)","stored.list.append(resi)")	#read info about residues STP
stored.list = list(map(str, stored.list))
hide lines, resn STP

#show spheres, resn STP
for my_index in stored.list: cmd.select("pocket"+my_index, "resn STP and resi "+my_index)
for my_index in stored.list: cmd.color(int(my_index)+1,"pocket"+my_index)
for my_index in stored.list: cmd.show("spheres","pocket"+my_index)
for my_index in stored.list: cmd.hide("sticks","pocket"+my_index)
for my_index in stored.list: cmd.set("sphere_scale","0.3","pocket"+my_index)
for my_index in stored.list: cmd.set("sphere_transparency","0.1","pocket"+my_index)