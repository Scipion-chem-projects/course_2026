#!/bin/bash
pymol 8tdu_cif.pml
