#!/bin/bash
vmd 8tdu_out.cif -e 8tdu_cif.tcl
