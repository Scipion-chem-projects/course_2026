load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/9907093.sdf, 9907093
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/9908783.sdf, 9908783
disable 9908783
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/11618268.sdf, 11618268
disable 11618268
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/11625818.sdf, 11625818
disable 11625818
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/42636535.sdf, 42636535
disable 42636535
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/44137675.sdf, 44137675
disable 44137675
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/50905713.sdf, 50905713
disable 50905713
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/51001932.sdf, 51001932
disable 51001932
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/52913813.sdf, 52913813
disable 52913813
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/56649450.sdf, 56649450
disable 56649450
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/70798655.sdf, 70798655
disable 70798655
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/135565159.sdf, 135565159
disable 135565159
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/000174_ProtocolLigandsFetching/extra/135565596.sdf, 135565596
disable 135565596
zoom