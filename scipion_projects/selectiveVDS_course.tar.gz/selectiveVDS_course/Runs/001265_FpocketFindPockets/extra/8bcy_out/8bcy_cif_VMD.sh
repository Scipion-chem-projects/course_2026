#!/bin/bash
vmd 8bcy_out.cif -e 8bcy_cif.tcl
