#!/bin/bash
pymol 8bcy_cif.pml
