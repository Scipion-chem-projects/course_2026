load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/006976_ProtOpenMMSystemSimulation/8tdu_system.pdb, 8tdu_system
hide spheres, 8tdu_system
show sticks, 8tdu_system
hide everything, resn HOH or resn WAT
zoom resn LIG
select ligand, resn LIG
label ligand and name CA, "%-s" % (ID)
label ligand and not name CA, "%-s" % (ID)
hide everything, (resn LIG) and (elem H)
color gray70, not resn LIG