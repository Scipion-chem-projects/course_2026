load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/001192_P2RankFindPockets/extra/8bcy.pdb
load /home/danieldh/ScipionUserData/projects/selectiveVDS_course/Runs/002142_ProtChemVinaDocking/outputLigands/g1_Taselisib-2_1.pdb, g1_Taselisib-2_1
hide spheres, g1_Taselisib-2_1
show sticks, g1_Taselisib-2_1
label g1_Taselisib-2_1, name